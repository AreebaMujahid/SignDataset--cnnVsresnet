import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from CustomDataset import SignDataset
import torch.nn.functional as F

class CNN(nn.Module):
    def __init__(self, num_classes, in_channels=3):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, 6, kernel_size=5)
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)
        self.fc1 = nn.Linear(16 * 22 * 22, 120)  # Adjust the input size based on your image dimensions
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, num_classes)

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), 2)
    
        # Calculate the size of the output from the last convolutional layer (self.conv2)
        conv2_output_size = x.view(x.size(0), -1).size(1)
    
        x = x.view(-1, conv2_output_size)  # Use the size of the output from the last convolutional layer
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
num_classes = 10  # Modify this according to your number of classes
learning_rate = 0.001
num_epochs = 4

model = CNN(num_classes=num_classes).to(device)
criterion = nn.CrossEntropyLoss()  # Use Cross Entropy Loss for multi-class classification
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

custom_dataset = SignDataset('dataset images', hr_shape=(100, 100))  # Update hr_shape to (100, 100)
data_loader = DataLoader(custom_dataset, batch_size=64, shuffle=True)

for epoch in range(num_epochs):
    print(f"Epoch: {epoch}")
    for batch_idx, (images, labels) in enumerate(data_loader):
        print("Batch shape:", images.shape)
        images = images.to(device=device)
        labels = labels.to(device=device)

        scores = model(images)
        print("Input shape:", images.shape)

        loss = criterion(scores, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

def check_accuracy(loader, model):
    num_correct = 0
    num_samples = 0
    model.eval()
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device=device)
            labels = labels.to(device=device)

            # Forward pass
            scores = model(images)

            # Get predictions
            _, predictions = scores.max(1)

            # Update counts
            num_correct += (predictions == labels).sum().item()
            num_samples += labels.size(0)

        accuracy = num_correct / num_samples * 100
        print(f"Got {num_correct} / {num_samples} with accuracy {accuracy:.2f}")

    model.train()

print("Train accuracy:")
check_accuracy(data_loader, model)
