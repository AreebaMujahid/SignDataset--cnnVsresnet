import torch
import torch.nn as nn
import torchvision.models as models
from CustomDataset import SignDataset
from torch.utils.data import DataLoader


# Assuming your dataset has 10 classes
num_classes = 10
# Learning rate definition
learning_rate = 0.001
# Load the pre-trained ResNet34 model
resnet_model = models.resnet34(pretrained=True)

# Modify the fully connected layer to match the number of classes in your dataset
resnet_model.fc = nn.Linear(resnet_model.fc.in_features, num_classes)


# Assuming your dataset is in the 'dataset images' directory
custom_dataset = SignDataset('dataset images', hr_shape=(100, 100)) 

# Create a DataLoader for your dataset
data_loader = DataLoader(custom_dataset, batch_size=64, shuffle=True)

# Define the loss function, optimizer, and move the model to GPU if available
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(resnet_model.parameters(), lr=learning_rate)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
resnet_model.to(device)

# Train the model
num_epochs = 4

for epoch in range(num_epochs):
    print(f"Epoch: {epoch}")
    for batch_idx, (images, labels) in enumerate(data_loader):
        images = images.to(device=device)
        labels = labels.to(device=device)

        scores = resnet_model(images)
        loss = criterion(scores, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

# Check accuracy
def check_accuracy(loader, model):
    model.eval()
    num_correct = 0
    num_samples = 0

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device=device)
            labels = labels.to(device=device)

            scores = model(images)
            _, predictions = scores.max(1)
            num_correct += (predictions == labels).sum()
            num_samples += predictions.size(0)

        print(f"Got {num_correct} / {num_samples} with accuracy {float(num_correct) / float(num_samples) * 100:.2f}")

    model.train()

print("Train accuracy:")
check_accuracy(data_loader, resnet_model)
